import "./App.css";

const curiosidades = [
  {
    number: "01",
    title: "Muy cariñosa",
    text: "Le encanta estar acompañada, recibir cariño y participar en todo lo que ocurre en casa.",
  },
  {
    number: "02",
    title: "Pequeña pero valiente",
    text: "Aunque es una Yorkshire pequeña, se comporta como si fuera la guardiana oficial de toda la familia.",
  },
  {
    number: "03",
    title: "Grandes dientes",
    text: "Tiene una apariencia muy tierna, pero también unos grandes dientes que sorprenden a cualquiera.",
  },
];

const fotos = [
  {
    src: "/images/marmota-1.jpg",
    alt: "Marmota disfrutando uno de sus momentos favoritos",
  },
  {
    src: "/images/marmota-2.jpg",
    alt: "Marmota mirando a la cámara",
  },
  {
    src: "/images/marmota-3.jpg",
    alt: "Una fotografía especial de Marmota",
  },
  {
    src: "/images/marmota-4.jpg",
    alt: "Marmota descansando",
  },
  {
    src: "/images/marmota-5.jpg",
    alt: "Marmota disfrutando una aventura",
  },
  {
    src: "/images/marmota-6.jpg",
    alt: "Otro momento inolvidable de Marmota",
  },
];

function Navbar() {
  return (
    <header className="navbar">
      <div className="container navbar-content">
        <a className="logo" href="#inicio" aria-label="Ir al inicio">
          Marmota<span>.</span>
        </a>

        <nav aria-label="Navegación principal">
          <a href="#historia">Historia</a>
          <a href="#personalidad">Personalidad</a>
          <a href="#galeria">Galería</a>
        </nav>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <section className="hero" id="inicio">
      <div className="container hero-grid">
        <div className="hero-content">
          <span className="eyebrow">Una Yorkshire muy especial</span>

          <h1>
            Hola, soy
            <span> Marmota</span>
          </h1>

          <p>
            Una perrita Yorkshire de 5 años, muy tierna, cariñosa y llena de
            personalidad. Es pequeña por fuera, pero tiene un enorme corazón y
            unos dientes aún más grandes.
          </p>

          <div className="hero-actions">
            <a className="primary-button" href="#historia">
              Conoce mi historia
            </a>

            <a className="secondary-button" href="#galeria">
              Ver fotografías
            </a>
          </div>

          <div className="hero-meta">
            <div className="meta-item">
              <strong>5 años</strong>
              <span>Edad</span>
            </div>

            <div className="meta-item">
              <strong>Yorkshire</strong>
              <span>Raza</span>
            </div>

            <div className="meta-item">
              <strong>100%</strong>
              <span>Ternura</span>
            </div>
          </div>
        </div>

        <div className="hero-visual">
          <div className="hero-image-wrapper">
            <img
              className="hero-image"
              src="/images/marmota-portada.jpg"
              alt="Fotografía principal de Marmota"
            />

            <div className="floating-card floating-card-top">
              <span>🐾</span>
              <div>
                <strong>Yorkshire</strong>
                <small>Pequeña y valiente</small>
              </div>
            </div>

            <div className="floating-card floating-card-bottom">
              <span>🦷</span>
              <div>
                <strong>Grandes dientes</strong>
                <small>Es parte de su encanto</small>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Historia() {
  return (
    <section className="section story-section" id="historia">
      <div className="container story-grid">
        <div className="story-image-wrapper">
          <img
            className="story-image"
            src="/images/marmota-historia.jpg"
            alt="Marmota durante uno de sus momentos especiales"
            loading="lazy"
          />

          <div className="story-badge">
            <strong>5</strong>
            <span>años llenando la casa de alegría</span>
          </div>
        </div>

        <div className="story-content">
          <span className="section-label">Su historia</span>

          <h2>Una pequeña compañera con una gran personalidad</h2>

          <p>
            Marmota llegó para convertirse en una integrante fundamental de la
            familia. Desde entonces, cada día tiene un poco más de alegría,
            compañía y momentos inesperados.
          </p>

          <p>
            Es una perrita muy tierna y cariñosa, aunque también sabe hacerse
            respetar. Su tamaño pequeño contrasta con su enorme personalidad y
            con esos grandes dientes que siempre llaman la atención.
          </p>

          <div className="story-list">
            <div className="story-list-item">
              <span>✓</span>
              <p>Especialista en conseguir atención con una mirada.</p>
            </div>

            <div className="story-list-item">
              <span>✓</span>
              <p>Siempre está pendiente de lo que sucede a su alrededor.</p>
            </div>

            <div className="story-list-item">
              <span>✓</span>
              <p>Pequeña, elegante, cariñosa y muy valiente.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Personalidad() {
  return (
    <section className="section section-soft" id="personalidad">
      <div className="container">
        <div className="section-heading">
          <span className="section-label">Su personalidad</span>
          <h2>Todo lo que hace especial a Marmota</h2>
          <p>
            Una combinación perfecta entre ternura, carácter y una personalidad
            imposible de ignorar.
          </p>
        </div>

        <div className="cards-grid">
          {curiosidades.map((curiosidad) => (
            <article className="info-card personality-card" key={curiosidad.title}>
              <span className="card-number">{curiosidad.number}</span>
              <h3>{curiosidad.title}</h3>
              <p>{curiosidad.text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

function Quote() {
  return (
    <section className="quote-section">
      <div className="container quote-content">
        <span className="quote-icon">“</span>

        <blockquote>
          Pequeña por fuera, gigante de corazón y con suficientes dientes para
          recordarnos quién manda en casa.
        </blockquote>

        <p>Marmota, probablemente</p>
      </div>
    </section>
  );
}

function Galeria() {
  return (
    <section className="section gallery-section" id="galeria">
      <div className="container">
        <div className="section-heading">
          <span className="section-label">Galería</span>
          <h2>Momentos de Marmota</h2>
          <p>
            Una selección de fotografías que muestran diferentes momentos,
            expresiones y aventuras.
          </p>
        </div>

        <div className="gallery-grid">
          {fotos.map((foto, index) => (
            <figure className="gallery-item" key={foto.src}>
              <img src={foto.src} alt={foto.alt} loading="lazy" />

              <figcaption>
                <span>0{index + 1}</span>
                <p>Momento Marmota</p>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-content">
        <div>
          <strong className="footer-logo">Marmota.</strong>
          <p>Una página creada con mucho cariño.</p>
        </div>

        <a href="#inicio">Volver al inicio ↑</a>

        <span>© {new Date().getFullYear()}</span>
      </div>
    </footer>
  );
}

function App() {
  return (
    <>
      <Navbar />

      <main>
        <Hero />
        <Historia />
        <Personalidad />
        <Quote />
        <Galeria />
      </main>

      <Footer />
    </>
  );
}

export default App;